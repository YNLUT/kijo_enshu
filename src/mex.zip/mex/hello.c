/*=================================================================
 * hello.c 
 * example for illustrating how to copy the string data from MATLAB
 * to a C-style string and send to console
 *
 * takes a row vector string and double iteration value
 * 
 * This is a MEX-file for MATLAB.
 * Copyright 2014 YNL, The University of Tokyo.
 *=============================================================*/

#include "mex.h"
#include <math.h>
/*
 * This file implements 
 * function name_len = hello(name, times)
 * name_len: length of name
 * name  : string
 * times : double
 */

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    char *output_buf;
    size_t buflen;
    int i;
    
    /* number of argument is 2 */
    if(nrhs!=2)
       mexErrMsgIdAndTxt( "MATLAB:hello:invalidNumInputs",  "Two inputs required.");
    
    /* only 1 return value */
    if(nlhs > 1) 
        mexErrMsgIdAndTxt( "MATLAB:hello:maxlhs", "Too many output arguments.");
   
    /* check argument types */
    /* first argument must be a string */
    /* if not, show error message and exit */
    if ( mxIsChar(prhs[0]) != 1)
        mexErrMsgIdAndTxt( "MATLAB:hello:inputNotString",  "First input must be a string.");
    
    /* second argument must be a number */
    if ( mxIsDouble(prhs[1]) != 1)
        mexErrMsgIdAndTxt( "MATLAB:hello:inputNotNumber",  "Second input must be a number.");

    /* second argument must be 1x1 (scalar) */
    if( (mxGetM(prhs[1])!=1)||(mxGetN(prhs[1])!=1) )
        mexErrMsgIdAndTxt( "MATLAB:hello:inputNotScalar",  "Second input must be a scalar value.");
    
    /* get the length of the input string */
    buflen = (mxGetM(prhs[0]) * mxGetN(prhs[0])) + 1;
    
    /* allocate memory for output_buf */
    output_buf=mxCalloc(buflen, sizeof(char));

    /* copy the string data from prhs[0] into a C string output_buf */
    output_buf=mxArrayToString(prhs[0]);

    for(i=0; i<(floor(mxGetScalar(prhs[1]))); i++)
        mexPrintf("Hello %s!\n", output_buf);

    /* set C-style string output_buf to MATLAB mexFunction output*/
    plhs[0] = mxCreateDoubleScalar(buflen);
    mxFree(output_buf);
    return;
}
