%HELLO Prints messages with argument to console
%  LEN = HELLO(NAME, ITER) Prints "Hello NAME!" for ITER times and
%  returns length of NAME to MATLAB console
