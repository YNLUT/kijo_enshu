#include "mex.h"
#include <windows.h>
#include <stdio.h>

HANDLE h;

void serial_comm(double* gain, int port)
{
	char s[1];
	char str[100];
	int baudRate = 19200;
	DCB dcb;
	unsigned long nn;
	COMMTIMEOUTS cto;
	int i;

    /*
    for(i = 0; i < 15; i++){    
		sprintf(str, "COM%d", i);
		h = CreateFile(str, GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
		if(h != INVALID_HANDLE_VALUE){
			break;
		}
	}
    */
    
    
    sprintf(str, "\\\\.\\COM%d", port);

    h = CreateFile(str, GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0);
	if (h == INVALID_HANDLE_VALUE){
		printf("Invalid handle value\n");
		return;
	}

	//printf("Connected to %s", str);

	GetCommState(h, &dcb);
	dcb.BaudRate = baudRate;
    dcb.ByteSize = 8;
    dcb.StopBits = ONESTOPBIT;
	SetCommState(h, &dcb);

	GetCommTimeouts(h, &cto);
	cto.ReadIntervalTimeout = 1000;
	cto.ReadTotalTimeoutMultiplier = 0;
	cto.ReadTotalTimeoutConstant = 1000;
	cto.ReadTotalTimeoutMultiplier = 0;
	cto.ReadTotalTimeoutConstant = 0;
	SetCommTimeouts(h, &cto);
/*
	for(i = 0; i < 8; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
	
	ReadFile(h, str, 9, &nn, 0);
	str[nn] = '\0';
	printf("%s", str);
*/		
	WriteFile(h, "start\r", 6, &nn, 0);
	for(i = 0; i < 8; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
	ReadFile(h, s, 1, &nn, 0);
	printf("%c", s[0]);
	
	
	ReadFile(h, s, 1, &nn, 0);
	sprintf(str, "%lf\r", gain[0]);
	WriteFile(h, str, strlen(str), &nn, 0);
	for(i = 0; i < 6; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
	ReadFile(h, s, 1, &nn, 0);
	printf("%c", s[0]);
	
	sprintf(str, "%lf\r", gain[1]);
	WriteFile(h, str, strlen(str), &nn, 0);
	for(i = 0; i < 6; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
	ReadFile(h, s, 1, &nn, 0);
	printf("%c", s[0]);
	
	sprintf(str, "%lf\r", gain[2]);
	WriteFile(h, str, strlen(str), &nn, 0);
	for(i = 0; i < 6; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
	ReadFile(h, s, 1, &nn, 0);
	printf("%c", s[0]);
	

	sprintf(str, "%lf\r", gain[3]);
	WriteFile(h, str, strlen(str), &nn, 0);
	for(i = 0; i < 40; ){
		ReadFile(h, s, 1, &nn, 0);
		printf("%c", s[0]);
		if(s[0] == '\n' || s[0] == '\r'){
			i++;
		}
	}
    
    CloseHandle(h);
	
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	int row, col;
	double *xp;
	int port;
    
    if(nrhs!=2){
        printf("Argument error\n");
        return;
    }
    
	row = mxGetM(*prhs);
	col = mxGetN(*prhs);

	if(row!=4 || col!=1){
		printf("Matrix Size Error\n");
		return;
	}
    
    row = mxGetM(*(prhs+1));
	col = mxGetN(*(prhs+1));
    
    if(row!=1 || col!=1){
		printf("Matrix Size Error\n");
		return;
	}
    
    xp = mxGetPr(prhs[0]);
    port = (int)mxGetScalar(prhs[1]);
    
    //printf("%d\n", port);
    
	serial_comm(xp, port);


}
