/*=================================================================
 * skew.c 
 * example for illustrating how to copy the string data from MATLAB
 * to a C-style string and send to console
 *
 * takes a row vector string and double iteration value
 * 
 * This is a MEX-file for MATLAB.
 * Copyright 2014 YNL, The University of Tokyo.
 *=============================================================*/

#include "mex.h"
#include <math.h>
/*
 * This file implements 
 * function name_len = hello(name, times)
 * name_len: length of name
 * name  : string
 * times : double
 */

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    double *mat;
    double *input_vector;
    int i;
    
    /* number of argument is 1 */
    if(nrhs!=1)
       mexErrMsgIdAndTxt( "MATLAB:skew:invalidNumInputs",  "One input required.");
    
    /* only 1 return value */
    if(nlhs > 1) 
        mexErrMsgIdAndTxt( "MATLAB:hello:maxlhs", "Too many output arguments.");
   
    /* check argument types */
    /* first argument must be a 3 dimensional real vector */
    /* if not, show error message and exit */
    if ( (mxIsDouble(prhs[0])!=1)
        ||(mxIsComplex(prhs[0])==1)
        ||(mxGetNumberOfDimensions(prhs[0])>2)
        ||( (mxGetM(prhs[0])==3)&&(mxGetN(prhs[0])!=1) ) /* vector is not 3x1 */
        ||( (mxGetM(prhs[0])==1)&&(mxGetN(prhs[0])!=3) ) /* vector is not 1x3 */
        )
        mexErrMsgIdAndTxt( "MATLAB:hello:inputNotNumber",  "First input must be a 3 dimensional real vector.");
    
    /* get pointer to real part of first argument */
    input_vector = mxGetPr(prhs[0]);

    /* allocate matrix for output */
    plhs[0] = mxCreateDoubleMatrix(3, 3, mxREAL);
    
    /* get pointer to real part of output */    
    mat = mxGetPr(plhs[0]);
    
    /* set values to matrix */
    mat[0] = 0;
    mat[1] = input_vector[2];
    mat[2] = -1*input_vector[1];
    mat[3] = -1*input_vector[2];
    mat[4] = 0;
    mat[5] = input_vector[0];
    mat[6] = input_vector[1];
    mat[7] = -1*input_vector[0];
    mat[8] = 0;
    
    return;
}

