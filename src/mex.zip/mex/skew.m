%SKEW calculates skew-symmetric matrix from a vector
%  A = SKEW( V ) V is 3D vector and A is 3x3 matrix
